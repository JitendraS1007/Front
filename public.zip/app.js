const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const authRoutes = require('./src/routes/auth');
const restroRoutes = require('./src/routes/restro');
const MongoConnection = require('./src/database/db');
const session = require('express-session');
const s3 = require('./src/helpers/config');
const i18n = require('i18n');
const path = require('path');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
const cors = require('cors');
app.use(cors());
require('dotenv').config();
app.set('view engine', 'ejs');
console.log(__dirname,'l');
app.set('views', path.join(__dirname, 'src/views'));

const cookieParser = require('cookie-parser');
app.use(cookieParser());
const PORT = process.env.PORT  || 5000;
MongoConnection();
app.use(session({
    secret: 'mysecretkey',
    resave: false,
    saveUninitialized: false,
}));
app.get('/', (req, res) => {
    if (req.session.userId) {
        return res.send(`Welcome ${req.session.username}, <a href="/logout">Logout</a>`);
    }
    res.redirect('/login');
});
app.get('/register', (req, res) => {
    res.render('register', { errors: null, message:null });
});
app.get('/login', (req, res) => {
    res.render('login', { errors: null, token:null });
});
i18n.configure({
    locales: ['en', 'es', 'fr'],
    directory: path.join(__dirname, 'src/locales'),
    defaultLocale: 'en',
    queryParameter: 'lang',
    autoReload: true,
    updateFiles: false, 
    syncFiles: true,
    cookie: 'locale'
});
app.use(i18n.init);
app.use(express.json());

app.use('/', authRoutes);
app.use('/api/restro', restroRoutes);
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});