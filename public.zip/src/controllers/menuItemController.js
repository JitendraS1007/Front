const express = require('express');
const upload = require('../helpers/storage');
const MenuItem = require('../modal/MenuItem');
const Restaurant = require('../modal/Restaurant');
const response = require('../helpers/response');
const { MenuItemSchema } = require('../middleware/validation');
const mongoose = require('mongoose');
exports.MenuAdd = async (req, res) => {
    try {
        await new Promise((resolve, reject) => {
            upload(req, res, (err) => {
                if (err) {
                    return reject({ message: err });
                }
                if (!req.files || req.files.length === 0) {
                    return reject({ message: 'No files uploaded.' });
                }
                resolve();
            });
        });
        const { name, price, quantity, foodtype, description } = req.body;
        const ownerId = req.user.id;
        const existing_item = await MenuItem.findOne({ name: name });
        if (existing_item) {
            return response.validationError(res, res.__('Menu_already_added'));
        }
        // Validate the request body
        const { error } = MenuItemSchema.validate(req.body, { abortEarly: false });
        if (error) {
            const errMessages = error.details.map(err => ({ message: err.message }));
            return response.validationError(res, errMessages);
        }
        const existingRestaurant = await Restaurant.findById(req.params.restaurant_id);
        if (!existingRestaurant) {
            return response.error(res, res.__('restaurant_not_found'), null, 404);
        }
        let image = null;
        if (req.files && req.files.length > 0) {
            image = req.files[0].filename; 
        }
        const restaurant = req.params.restaurant_id;
        if (!mongoose.Types.ObjectId.isValid(restaurant)) {
            return response.error(res, res.__('invalid_restaurant_id'), null, 400);
        }
        const newMenu = new MenuItem({ name, price, quantity, description, foodtype, image, ownerId, restaurant });
        const savedMenu = await newMenu.save();
        return response.success(res, res.__('Menu_added_successfully'), savedMenu, 201);

    } catch (error) {
        console.log(error);
        return response.error(res, res.__('server_error'), error.message);
    }
};


exports.MenuList = async (req, res) => {
    try{
        const { restaurantId } = req.query;
        let query ={};
        if (restaurantId) {
            query.restaurant = restaurantId
        }else{
            const { name } = req.query;
            if (name) {
                query.name = { $regex: name, $options: 'i' };
            }
        }
        const menu = await MenuItem.find( query  ).populate('restaurant', 'name').select('_id name price quantity image foodtype restaurant');
        return response.success(res, res.__('menu_List'), menu, 200);
    }catch (error) {
        return response.error(res, res.__('server_error'), error.message);
    }

}

exports.MenuEdit = async (req, res) => {
    try {
        const { menuId } = req.params;
        const existingMenuItem = await MenuItem.findById(menuId);
        if (!existingMenuItem) {
            return response.error(res, res.__('menuItem_not_found'), null, 404);
        }
        new Promise((resolve, reject) => {
            upload(req, res, (err) => {
                if (err) {
                    return reject({ message: err });
                }
                resolve();
            });
        })
        .then(async () => {
            const { name, price, quantity, foodtype, description } = req.body;
            existingMenuItem.name           = name || existingMenuItem.name;
            existingMenuItem.price          = price || existingMenuItem.price;
            existingMenuItem.quantity       = quantity || existingMenuItem.quantity;
            existingMenuItem.foodtype       = foodtype || existingMenuItem.foodtype;
            existingMenuItem.description    = description || existingMenuItem.description;
            if (req.files && req.files.length > 0) {
                const uploadedImage = req.files[0].filename;
                if (existingMenuItem.image) {
                    const oldImagePath = path.join(__dirname, '../../public/uploads/images/dishes', existingMenuItem.image);
                    if (fs.existsSync(oldImagePath)) {
                        fs.unlinkSync(oldImagePath);
                    }
                }
                existingMenuItem.image = uploadedImage;
            }
            const updatedMenuItem = await existingMenuItem.save();
            return response.success(res, res.__('MenuItem_updated_successfully'), updatedMenuItem, 200);
        })
        .catch(err => {
            return res.status(400).json({ message: err.message });
        });

    } catch (error) {
        return response.error(res, res.__('server_error'), error.message);
    }

}
exports.MenuStatusUpdate = async (req, res) => {
    try{
        const { restroId } = req.params;
        const updatedMenuItem = await MenuItem.findOneAndUpdate(
            { _id: restroId },
            [
                { 
                    $set: { status: { $cond: { if: { $eq: ["$status", 1] }, then: 0, else: 1 } } }
                }
            ],
            { new: true }
        );
        if (!updatedMenuItem) {
            return response.error(res, res.__('MenuItem_not_found'), null, 404);
        }
        return response.success(res, res.__('MenuItem_status_updated_successfully'), updatedMenuItem, 200);
    }catch(error){
        return response.error(res, res.__('server_error'), error.message);
    }
}