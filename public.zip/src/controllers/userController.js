const express = require('express');
const User = require('../modal/User');
const response = require('../helpers/response');
exports.UserList = async (req, res) => {
    try {
        const user = await User.find({ _id: { $ne: req.user.id } }).select('_id username email mobile countryCode');
        if(user.length==0){
            return response.success(res, res.__('user_not_found'), [], 200);
        }
        return response.success(res, res.__('user_found_sucessfully'), user, 200);

    }catch (error) {
        return response.error(res, res.__('server_error'), error.message);
    }

}