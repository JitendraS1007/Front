const express = require('express');
exports.changeLang = async (req, res) => {
    const newLang = req.params.lang;
    res.setLocale(newLang);
    res.cookie('locale', newLang);
    res.json({ message: res.__('Language_change_successful')  });
};