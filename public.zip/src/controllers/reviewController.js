const Review = require('../modal/Reviews');
const response = require('../helpers/response');
const Order = require('../modal/Order');
exports.createReview = async (req, res) => {
    try {
        const {  restaurant_id, rating, review_text } = req.body;
        const user_id = req.user.id;
        const userOrders = await Order.find({ user_id, restaurant_id });
        if (userOrders.length === 0) {
            return response.validationError(res, res.__('You_can_only_review_a_restaurant_if_you_have_ordered_from_it.'));
            
        }
        const existingReview = await Review.findOne({ user_id, restaurant_id });
        if (existingReview) {
            return response.validationError(res, res.__('You_have_already_submitted_a_review_for_this_restaurant..'));
        }
        const newReview = new Review({ user_id, restaurant_id, rating, review_text });
        const savedReview = await newReview.save();
        return response.success(res, res.__('Review_added_successfully'), savedReview, 201);
    } catch (error) {
        return response.error(res, res.__('server_error'), error.message);
    }
};

// Get reviews for a specific restaurant
exports.getReviewsByRestaurant = async (req, res) => {
    try {
        const { restaurant_id } = req.params;
        const reviews = await Review.find({ restaurant_id }).populate('user_id', 'username email');
        return response.success(res, res.__('Review_get_successfully'), reviews, 201);
    } catch (error) {
        return res.status(400).json({ message: err.message });
    }
};

// Delete a review
exports.deleteReview = async (req, res) => {
    try {
        const { review_id } = req.params;

        const review = await Review.findByIdAndDelete(review_id);
        if (!review) {
            return response.error(res, res.__('Review_not_found'), null, 404);
        }
        return response.success(res, res.__('Review_deleted_successfully'), [], 200);
    } catch (error) {
        return res.status(400).json({ message: err.message });
    }
};
