const Restaurant = require('../modal/Restaurant');
const moment = require('moment');
const response = require('../helpers/response');
const { restaurantSchema } = require('../middleware/validation');
const Upload = require('../helpers/storage');
const path = require('path');
const fs = require('fs');
exports.resturantAdd = async (req, res) => {
    try {
        await new Promise((resolve, reject) => {
            Upload(req, res, (err) => {
                if (err) {
                    return reject({ message: err });
                }
                if (!req.files || req.files.length === 0) {
                    return reject({ message: 'No files uploaded.' });
                }
                resolve();
            });
        });

        const { name, address, pincode, openingtime, closingtime ,phone_number ,email } = req.body;
        const ownerId = req.user.id;
        // Validate request body
        const { error } = restaurantSchema.validate(req.body, { abortEarly: false });
        if (error) {
            const errMessages = error.details.map(err => ({ message: err.message }));
            return response.validationError(res, errMessages);
        }
        const existing_restaurant = await Restaurant.findOne({ $or: [ { name: name }, { email: email },   { phone_number: phone_number } ]});
        if (existing_restaurant) {
            return response.validationError(res, res.__('Restaurant_name_email_mobile_will_be_uniq'));
        }
        let image = null;
        if (req.files && req.files.length > 0) {
            image = req.files[0].filename;
        }
        const newRestaurant = new Restaurant({ 
            name, address, pincode, openingtime, closingtime, ownerId, image ,phone_number ,email
        });
        const savedRestaurant = await newRestaurant.save();
        return response.success(res, res.__('restaurant_added_successfully'), savedRestaurant, 201);
    } catch (error) {
        console.log(error);
        if (!res.headersSent) {
            return response.error(res, res.__('server_error'), error.message);
        }
    }
};

exports.resturantList = async (req, res) => {
    try {
        const { name } = req.query;
        let query = {};
        
        if (name) {
            query.name = { $regex: name, $options: 'i' };
        }
        if(req.user.role == 2){
            query.ownerId = req.user.id;
        }
        const restaurants = await Restaurant.find( query  ).sort({ createdAt: -1 });
        const currentTime = moment();
        const updatedRestaurants = restaurants.map((restaurant) => {
            const openingTimeFormatted = new Date(restaurant.openingtime).toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit',
                hour12: true  
            });
            const closeingTimeFormatted = new Date(restaurant.closingtime).toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit',
                hour12: true  
            });
            return {
                ...restaurant._doc,
                openingtime: openingTimeFormatted,
                closingtime: closeingTimeFormatted
                
            };
        });
        return response.success(res, res.__('restaurant_List'), updatedRestaurants, 200);
    }catch (error) {
        return response.error(res, res.__('server_error'), error.message);
    }
}
exports.restroEdit = async (req, res) => {
    try {
        const { restroId } = req.params;
        const existingrestro = await Restaurant.findById(restroId);
        if (!existingrestro) {
            return response.error(res, res.__('restaurant_not_found'), null, 404);
        }
        new Promise((resolve, reject) => {
            Upload(req, res, (err) => {
                if (err) {
                    return reject({ message: err });
                }
                resolve();
            });
        })
        .then(async () => {
            const { name, location, openingtime, closingtime, pincode ,email ,phone_number} = req.body;
            const existing_restaurant = await Restaurant.findOne({$or: [ { name: name }, { email: email }, { phone_number: phone_number } ], _id: { $ne: restroId }});
            if (existing_restaurant) {
                return response.validationError(res, res.__('Restaurant_name_email_mobile_will_be_uniq'));
            }
            existingrestro.name         = name || existingrestro.name;
            existingrestro.location     = location || existingrestro.location;
            existingrestro.pincode      = pincode || existingrestro.pincode;
            existingrestro.openingtime  = openingtime || existingrestro.openingtime;
            existingrestro.closingtime  = closingtime || existingrestro.closingtime;
            if (req.files && req.files.length > 0) {
                const uploadedImage = req.files[0].filename;
                if (existingrestro.image) {
                    const oldImagePath = path.join(__dirname, '../../public/uploads/images/restaurants', existingrestro.image);
                    if (fs.existsSync(oldImagePath)) {
                        fs.unlinkSync(oldImagePath);
                    }
                }
                existingrestro.image = uploadedImage;
            }
            const updatedRestro = await existingrestro.save();
            return response.success(res, res.__('restaurant_updated_successfully'), updatedRestro, 200);
        })
        .catch(err => {
            return res.status(400).json({ message: err.message });
        });

    } catch (error) {
        return response.error(res, res.__('server_error'), error.message);
    }
};
exports.resturnatStatusUpdate = async (req,res)=>{
    try{
        const { restroId } = req.params;
        const updatedRestaurant = await Restaurant.findOneAndUpdate(
            { _id: restroId },
            [
                { 
                    $set: { status: { $cond: { if: { $eq: ["$status", 1] }, then: 0, else: 1 } } }
                }
            ],
            { new: true }
        );
        if (!updatedRestaurant) {
            return response.error(res, res.__('restaurant_not_found'), null, 404);
        }
        return response.success(res, res.__('restaurant_status_updated_successfully'), updatedRestaurant, 200);
    }catch(error){
        return response.error(res, res.__('server_error'), error.message);
    }
}
