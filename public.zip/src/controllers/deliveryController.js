const Delivery = require('../modal/Delivery');
const response = require('../helpers/response');
const Order = require('../modal/Order');
exports.createDelivery = async (req, res) => {
    const { order_id } = req.body;
    try { 
        const existing_order = await Order.find({ _id: order_id });
        if (!existing_order) {
            return response.validationError(res, res.__('Order_not_exists'));
        }
        const existing_delivery = await Delivery.findOne({ order_id });
        if (existing_delivery) {
            return response.validationError(res, res.__('Order_already_assign'));
        }
        const driver_id = req.user.id;
        const newDelivery = new Delivery({ order_id, driver_id,  delivery_status: 'Pending' });
        const delivery = await newDelivery.save();
        return response.success(res, res.__('order_assign_sucessfully'), delivery, 201);
       
    } catch (error) {
        console.log(error)
        return response.error(res, res.__('server_error'), error.message);
    }
};

exports.updateDeliveryStatus = async (req, res) => {
    const { deliveryId } = req.params;
    const { delivery_status } = req.body;

    try {
        const existing_delivery = await Delivery.findById(deliveryId);
        if (!existing_delivery) {
            return response.notFoundError(res, res.__('Delivery_not_found'));
        }
        const existing_order = await Order.findById(existing_delivery.order_id);
        if (existing_order && existing_order.payment_status === 'paid') {
            if (delivery_status === 'Delivered') {
                existing_delivery.delivery_time = Date.now();
            } else {
                existing_delivery.delivery_time = undefined; 
            }
        }else{
            return response.validationError(res, res.__('Payment_pending'));
        }
        existing_delivery.delivery_status = delivery_status;
        const updatedDelivery = await existing_delivery.save();
        return response.success(res, res.__('Delivery_status_updated_successfully'), updatedDelivery, 200);
    } catch (error) {
        console.error(error);
        return response.error(res, res.__('server_error'), error.message);
    }
};
exports.getDeliveryDetails = async (req, res) => {
    const { deliveryId } = req.params;
    try {
        const delivery = await Delivery.findById(deliveryId)
            .populate('order_id', 'order')
            .populate('driver_id', 'name vehicle_number');

        if (!delivery) {
            return response.notFoundError(res, res.__('Delivery_not_found'));
        }
        return response.success(res, res.__('Delivery_status_updated_successfully'), delivery, 200);
    } catch (error) {
        return response.error(res, res.__('server_error'), error.message);
    }
};
