const Cart = require('../modal/Cart');
const response = require('../helpers/response');
const MenuItem = require('../modal/MenuItem'); // Import the MenuItem model

exports.cartAdd = async(req, res) => {
    try{
        const {  menuItemId, quantity } = req.body
        const userId = req.user.id;
        const existingMenuItem = await MenuItem.findById(menuItemId);
        let cart = await Cart.findOne({ user_id: userId });
        if (!cart) {
            cart = new Cart({ user_id: userId, items: [] });
        }else{
            if(!cart.restaurant.equals(existingMenuItem.restaurant) && cart.items.length ){
                return response.validationError(res, res.__('same_restaurant_order_allow'));
            }
        } 
        cart.restaurant =existingMenuItem.restaurant
        const existingItem = cart.items.find(item => item.menu_item_id.toString() === menuItemId);
        if (existingItem) {
            existingItem.quantity += quantity;
        } else {
            cart.items.push({ menu_item_id: menuItemId, quantity });
        }
        await cart.save();
        return response.success(res, res.__('Cart_added_successfully'), [], 201);
    }catch(error){
        console.log(error);
        return response.error(res, res.__('server_error'), error.message);
    }
}

exports.cartList = async(req, res) => {
    try{
        const userId = req.user.id;
        const cart = await Cart.findOne({ user_id: userId })
            .populate({
                path: 'items.menu_item_id',
                select: 'name price quantity image foodtype ',
                populate: { path: 'restaurant', select: 'name' }  // Nested populate to get restaurant name
            });
            return response.success(res, res.__('cart_List'), cart, 200);
    }catch(error){
        return response.error(res, res.__('server_error'), error.message);
    }
}

exports.removeItemFromCart = async (req, res) => {
    try {
        const userId = req.user.id;
        const itemId = req.params.itemId;
        const cart = await Cart.findOne({ user_id: userId });
        if (!cart) {
            response.error(res, res.__('restaurant_not_found'), null, 404);
        }
        const updatedItems = cart.items.filter(item => item.menu_item_id.toString() !== itemId);
        cart.items = updatedItems;
        await cart.save();
        return response.success(res, res.__('Item_removed_from_cart_successfully'), cart, 200);
        
    } catch (error) {
        return response.error(res, res.__('server_error'), error.message);
    }
};

