const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../modal/User');
const crypto = require('crypto');
const response = require('../helpers/response');
const { registerValidationSchema } = require('../middleware/validation');
const { transport ,getResetPasswordHtml , getPasswordChangeHtml ,getRegisterHtml} = require('../services/emailService')
exports.register = async (req, res) => {
    const { username, email, password, mobile, countryCode ,accountType , license} = req.body;
    const { error } = registerValidationSchema.validate(req.body, { abortEarly: false }); //validation
    if (error) {
        const errMessages = error.details.map(err => ({ message: err.message }));
        if(req.body.web) return res.render('register', { errors: errMessages  , messgae:null});
        return response.validationError(res, errMessages);
    }
    const existingUser = await User.findOne({ $or: [ { email: email }, { mobile: mobile } ] });
    if (existingUser) {
        return response.validationError(res, res.__('User_exists'));
    }
    const token = crypto.randomBytes(32).toString('hex');
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ username, email, password: hashedPassword, mobile, countryCode ,accountType ,license ,resetToken:token});
    try {
        await newUser.save();
        const link = `${req.protocol}://${req.headers.host}/emailverify?token=${token}`;
        const data  = await getRegisterHtml(username,link);
        const info =  transport.sendMail({
            from: '"fooddevliver " <process.env.SENDER_MAIL>',
            to: email,
            subject: "Register User",
            html: data, 
          }); 
        return response.success(res, res.__('User_register'), newUser, 201);
    } catch (error) {
        console.log(error.message)
        return response.error(res, res.__('Error_registering_user'), error.message);
    }
}

exports.login = async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !(await bcrypt.compare(password, user.password))) {
        req.session.errorMessage = 'Invalid email or password.';
        return response.validationError(res, res.__('Invalid_credentials'));
    }
    if(!user.emailVerified) return response.validationError(res, res.__('email_not_verified'));
    const token = {"token":jwt.sign({ id: user._id  ,role:user.accountType , email:user.email}, process.env.JWT_SECRET, { expiresIn: '5h' })};
    return response.success(res, res.__('login_sucessfully'),  token, 201);
}

exports.reset = async (req, res) => {
    const { email } = req.body;
    const user = await User.findOne({ email });
    if (!user) {
        return response.notFoundError(res, res.__('User_not_found'));
    }
    const token = crypto.randomBytes(32).toString('hex');
    user.resetToken = token;
    user.resetTokenExpiration = Date.now() + 3600000;
    await user.save();
    const link  =   `${req.protocol}://${req.headers.host}/api/auth/save-password?token=${token}`;
    const data  = await getResetPasswordHtml(link);
    const info =  transport.sendMail({
        from: '"fooddevliver " <process.env.SENDER_MAIL>',
        to: email,
        subject: "Reset Password",
        html: data, 
      });   
      
    res.status(200).json({ message: res.__('Password_reset_link') });  
}

exports.savePassword = async (req, res) => {
    try{
        const { newPassword, confirmPassword } = req.body;
        const resetToken = req.query.token;
        if (!newPassword || !confirmPassword || !resetToken) {
            return response.validationError(res, res.__('fields_required'));
        }
        const user = await User.findOne({ resetToken, resetTokenExpiration: { $gt: Date.now() } });
        if (!user) {
            return response.validationError(res, res.__('Invalid_expired_token'));
        }
        if (newPassword !== confirmPassword) {
            return response.validationError(res, res.__('Passwords_do_not_match'));
        }
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        user.password = hashedPassword;
        user.resetToken   = undefined;
        user.resetTokenExpiration = undefined;
        const newUser = await user.save();
        const data  = await getPasswordChangeHtml();
        transport.sendMail({
            from: '"fooddevliver " <process.env.SENDER_MAIL>',
            to: user.email,
            subject: "Reset Password",
            html: data, 
        });   
        return response.success(res, res.__('Password_reset_successful'), [], 201);
    }catch(err){
        return response.error(res, res.__('Error_registering_user'), error.message);
    }
}

exports.emailVerify = async(req,res) => {
    const resetToken = req.query.token;
    try{
        if (!resetToken) {
            return response.validationError(res, res.__('fields_required'));
        }
        const user = await User.findOne({ resetToken });
        if (!user) {
            return response.validationError(res, res.__('user_not_found'));
        }
        user.emailVerified = true;
        user.resetToken   = undefined;
        await user.save();
        return response.success(res, res.__('Email_verfiy_successful'), [], 201);
    }catch(err){
        return response.error(res, res.__('Error_email_verify_user'), error.message);
    }
}