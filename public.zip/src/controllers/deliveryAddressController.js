const DeliveryAddress = require('../modal/DeliveryAddress');
const { deliveryAddressSchema } = require('../middleware/validation');
const response = require('../helpers/response');
exports.createDeliveryAddress = async (req, res) => {
    try {
        const { error } = deliveryAddressSchema.validate(req.body);
        if (error) {
            return res.status(400).json({ message: error.details[0].message });
        }
        const { address_line1, address_line2, city, state, postal_code, country, contact_number, delivery_instructions, is_default } = req.body;
        const user_id = req.user.id;
        if (is_default) {
            await DeliveryAddress.updateMany({ user_id }, { $set: { is_default: false } });
        }
        const newAddress = new DeliveryAddress({ user_id, address_line1, address_line2, city, state, postal_code, country, contact_number, delivery_instructions, is_default });
        const savedAddress = await newAddress.save();
        return response.success(res, res.__('Address_added_successfully'), savedAddress, 201);
    } catch (error) {
        console.log(error);
        return response.error(res, res.__('server_error'), error.message);
    }
};

exports.getDeliveryAddresses = async (req, res) => {
    try {
        const user_id = req.user.id; 
        const address_id = req.params.address_id
        let addresses = {};
        if(address_id){
             addresses = await DeliveryAddress.find({ _id: address_id }  );
        }else{
             addresses = await DeliveryAddress.find({ user_id });
        }
        return response.success(res, res.__('Address_retrieved_successfully'), addresses, 200);
    } catch (error) {retrieved
        console.log(error);
        return response.error(res, res.__('server_error'), error.message);
    }
};

exports.updateDeliveryAddress = async (req, res) => {
    try {
        const { error } = deliveryAddressSchema.validate(req.body);
        if (error) {
            return res.status(400).json({ message: error.details[0].message });
        }
        const { address_id } = req.params;
        const { address_line1, address_line2, city, state, postal_code, country, contact_number, delivery_instructions, is_default } = req.body;
        const user_id = req.user.id;
        if (is_default) {
            await DeliveryAddress.updateMany({ user_id }, { $set: { is_default: false } });
        }
        const updatedAddress = await DeliveryAddress.findOneAndUpdate(
            { _id: address_id, user_id },
            { address_line1, address_line2, city, state, postal_code, country, contact_number, delivery_instructions, is_default },
            { new: true } 
        );

        if (!updatedAddress) {
            return response.error(res, res.__('Address_not_found'), null, 404);
        }
        return response.success(res, res.__('Address_updated_successfully'), updatedAddress, 200);
    } catch (error) {
        console.log(error);
        return response.error(res, res.__('server_error'), error.message);
    }
};

exports.deleteDeliveryAddress = async (req, res) => {
    try {
        const { address_id } = req.params;
        const user_id = req.user.id;

        const deletedAddress = await DeliveryAddress.findOneAndDelete({ _id: address_id, user_id });

        if (!deletedAddress) {
            return response.error(res, res.__('Address_not_found'), null, 404);
        }
        return response.success(res, res.__('Address_deleted_successfully'), addresses, 200);
    } catch (error) {
        console.log(error);
        return response.error(res, res.__('server_error'), error.message);
    }
};
