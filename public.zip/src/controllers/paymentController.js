const Payment = require('../modal/Payment');
const response = require('../helpers/response');
const Order = require('../modal/Order');

exports.createPayment = async (req, res) => {
    const { order_id, user_id, amount, payment_method, payment_status } = req.body;
    try {
        const newPayment = new Payment({
            order_id,
            user_id,
            amount,
            payment_method,
            payment_status,
        });
        const payment = await newPayment.save();
        const updatedDelivery = await Order.findByIdAndUpdate(
            order_id,
            { 
                status:'Delivered',
                payment_status:'paid',
                delivery_time: Date.now()
            },
            { new: true }
        );
        return response.success(res, res.__('Payment_created_successfully'), payment, 201);
    } catch (error) {
        return response.error(res, res.__('server_error'), error.message);
    }
};
exports.getPaymentDetails = async (req, res) => {
    const { paymentId } = req.params;
    try {
        const payment = await Payment.findById(paymentId)
            .populate('order_id', 'total_price')
            .populate('user_id', 'username email');  
            console.log(payment,'payment');
        if (!payment) {
            return response.notFoundError(res, res.__('Payment_not_found'));
        }
        return response.success(res, res.__('Payment_fecth_successfully'), payment, 201);
    } catch (error) {
        return response.error(res, res.__('server_error'), error.message);
    }
};

exports.updatePaymentStatus = async (req, res) => {
    const { paymentId } = req.params;
    const { payment_status } = req.body;
    try {
        const updatedPayment = await Payment.findByIdAndUpdate(
            paymentId,
            { payment_status },
            { new: true }
        );
        if (!updatedPayment) {
            return response.notFoundError(res, res.__('Payment_not_found'));
        }
        return response.success(res, res.__('Payment_status_pdated_successfully'), updatedPayment, 200);
    } catch (error) {
        return response.error(res, res.__('server_error'), error.message);
    }
};
