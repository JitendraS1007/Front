const nodemailer = require("nodemailer");

const transport = nodemailer.createTransport({
    host: "sandbox.smtp.mailtrap.io",
    port: 2525,
    auth: {
        user: "4c35ac1fca2caa", 
        pass: "6ea71fab6fcfad"  
    }
});
const getResetPasswordHtml = (link) => `
  <html>
    <body style="font-family: Arial, sans-serif; padding: 20px;">
      <h2 style="color: #333;">Reset Your Password</h2>
      <p style="color: #555;">Hello,</p>
      <p style="color: #555;">You requested a password reset. Click the link below to set a new password:</p>
      <p>
      <a href="${link}" class="btn">Click Button</a>
      </p>
      <p style="color: #555;">If you did not request this, please ignore this email.</p>
      <p style="color: #555;">Thank you!</p>
      <p style="color: #555;">Best Regards,<br/>Food Delivery Team</p>
    </body>
  </html>
`;
const getPasswordChangeHtml = (link) => `
  <html>
    <body style="font-family: Arial, sans-serif; padding: 20px;">
      <h2 style="color: #333;">Your Password Change</h2>
      <p style="color: #555;">Hello,</p>
      <p style="color: #555;">Your Password Scuessfully change </p>
      <p style="color: #555;">Thank you!</p>
      <p style="color: #555;">Best Regards,<br/>Food Delivery Team</p>
    </body>
  </html>
`;
const getRegisterHtml = (name ,confirmRegister) => `
  <html>
    <body style="font-family: Arial, sans-serif; padding: 20px;">
      <div class="container">
        <div class="header">
            <h1>Welcome to [Your Company]</h1>
        </div>
        <div class="content">
            <h2>Hello ${name},</h2>
            <p>Thank you for registering with us. We're excited to have you on board!</p>
            <p>Please confirm your registration by clicking the button below:</p>
            <p>
                <a href="${confirmRegister}" class="btn">Confirm Registration</a>
            </p>
            <p>If you did not create an account, no further action is required.</p>
            <p>Best Regards,<br>[Your Company] Team</p>
        </div>
        <div class="footer">
            <p>&copy; [Year] [Your Company]. All Rights Reserved.</p>
        </div>
    </div>
    </body>
  </html>
`;
const getOrderHtml = (orderNumber) => `
  <html>
    <body style="font-family: Arial, sans-serif; padding: 20px;">
      <h2 style="color: #333;">Order Placed</h2>
      <p style="color: #555;">Hello Customer ,</p>
      <p style="color: #555;">Your Order has been Placed Your Order id  ${orderNumber}</p>
      <p style="color: #555;">Thank you!</p>
      <p style="color: #555;">Best Regards,<br/>Food Delivery Team</p>
    </body>
  </html>
`;
module.exports = {transport ,getResetPasswordHtml ,getPasswordChangeHtml , getRegisterHtml ,getOrderHtml};
