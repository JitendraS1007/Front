const express = require('express');
const router = express.Router();
const ResturantController = require('../controllers/restroController')
const Menucontroller = require('../controllers/menuItemController')
const CartController = require('../controllers/cartController');
const OrderController = require('../controllers/orderController');
const deliveryController = require('../controllers/deliveryController');
const paymentController = require('../controllers/paymentController');
const reviewController = require('../controllers/reviewController');
const DeliveryAddressController = require('../controllers/deliveryAddressController');
const verifyTokenAndRole = require('../middleware/tokenVerify');

//-------------------------------Restaurant Routes-----------------------------------//
router.post('/add-resturant',verifyTokenAndRole([2]), ResturantController.resturantAdd);
router.get('/get-restaurants', verifyTokenAndRole ([1,2]),ResturantController.resturantList);
router.put('/:restroId', verifyTokenAndRole([2]), ResturantController.restroEdit);
router.post('/restroId', verifyTokenAndRole([2]), ResturantController.resturnatStatusUpdate);

//-------------------------------Menu Routes-----------------------------------//
router.post('/additem/:restaurant_id',verifyTokenAndRole([2]) , Menucontroller.MenuAdd);
router.get('/:restaurant_id/menu_items',verifyTokenAndRole([1,2]) , Menucontroller.MenuList);
router.put('/menu_items/:menuId', verifyTokenAndRole([2]), Menucontroller.MenuEdit);
router.put('/dishes_status/:dishId', verifyTokenAndRole([2]), Menucontroller.MenuStatusUpdate);

//-------------------------------Cart Routes-----------------------------------//
router.post('/addCart/save',verifyTokenAndRole([1,2]) , CartController.cartAdd);
router.get('/cartList',verifyTokenAndRole([1,2]) , CartController.cartList);
router.delete('/cart/items/:itemId', verifyTokenAndRole([1,2]) ,CartController.removeItemFromCart);

//-------------------------------Order Routes-----------------------------------//
router.post('/order/save',verifyTokenAndRole([1,2]) , OrderController.createOrder);
router.get('/getorder',verifyTokenAndRole([1,2]) , OrderController.getOrder);
router.delete('/order/:id',verifyTokenAndRole([1,2]) , OrderController.deleteOrder);


//-------------------------------Delivery Routes-----------------------------------//
router.post('/deliveries',verifyTokenAndRole([3])  , deliveryController.createDelivery);
router.put('/deliveries/:deliveryId',verifyTokenAndRole([3]) , deliveryController.updateDeliveryStatus);
router.get('/deliveries/:deliveryId', verifyTokenAndRole([3]) ,deliveryController.getDeliveryDetails);

//-------------------------------Payment Routes-----------------------------------//
router.post('/payments', verifyTokenAndRole([3])  ,paymentController.createPayment);
router.get('/payments/:paymentId', verifyTokenAndRole([3]) ,paymentController.getPaymentDetails);
router.put('/payments/:paymentId', verifyTokenAndRole([3]) , paymentController.updatePaymentStatus);


//-------------------------------Review Routes-----------------------------------//
router.post('/reviews', verifyTokenAndRole([1, 2]), reviewController.createReview);
router.get('/reviews/:restaurant_id', reviewController.getReviewsByRestaurant);
router.delete('/reviews/:review_id', verifyTokenAndRole([1]), reviewController.deleteReview);

//-------------------------------Delivery Routes-----------------------------------//
router.post('/delivery-address', verifyTokenAndRole([1]), DeliveryAddressController.createDeliveryAddress);
router.put('/delivery-address/:address_id', verifyTokenAndRole([1]), DeliveryAddressController.updateDeliveryAddress);
router.get('/delivery-address', verifyTokenAndRole([1]), DeliveryAddressController.getDeliveryAddresses);
router.get('/delivery-address/:address_id', verifyTokenAndRole([1]), DeliveryAddressController.getDeliveryAddresses);
router.delete('/delivery-address/:address_id', verifyTokenAndRole([1]), DeliveryAddressController.deleteDeliveryAddress);


module.exports = router;
