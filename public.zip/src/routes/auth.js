const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const HomeController = require('../controllers/homeController');
const UserController = require('../controllers/userController');
const verifyTokenAndRole = require('../middleware/tokenVerify');
// const ResturantController = require('../controllers/restaurantController')
router.post('/register', authController.register);
router.post('/login', authController.login);
router.post('/forgot-password', authController.reset);
router.post('/save-password', authController.savePassword);
router.get('/emailverify',authController.emailVerify);
router.get('/change-lang/:lang',HomeController.changeLang);
router.get('/userlist',verifyTokenAndRole([4]),UserController.UserList);
// router.post('/add-resturant', ResturantController.resturantAdd);
module.exports = router;