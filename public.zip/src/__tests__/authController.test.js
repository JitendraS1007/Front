const request = require('supertest');
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../modal/User'); // Adjust the path as necessary
const { register } = require('../controllers/authController'); // Adjust the path as necessary
const response = require('../helpers/response');
const { transport, getRegisterHtml } = require('../services/emailService');
const { registerValidationSchema } = require('../middleware/validation');
jest.mock('../modal/User');
jest.mock('../services/emailService');

const app = express();
app.use(express.json());
app.post('/register', register);

describe('Register Controller', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('should register a new user successfully', async () => {
        const mockUser = {
            username: 'testuser',
            email: 'test@example.com',
            password: 'password123',
            mobile: '1234567890',
            countryCode: 'US',
            accountType: 'standard',
            license: 'AB123456',
        };

        User.findOne.mockResolvedValue(null); // No existing user
        User.prototype.save.mockResolvedValue(mockUser); // Mock save method

        transport.sendMail.mockResolvedValue({}); // Mock email sending

        const response = await request(app)
            .post('/register')
            .send(mockUser);

        expect(response.status).toBe(201);
        expect(response.body.message).toBe('User registered successfully');
        expect(User.findOne).toHaveBeenCalledWith({
            $or: [{ email: mockUser.email }, { mobile: mockUser.mobile }],
        });
        expect(User.prototype.save).toHaveBeenCalled();
        expect(transport.sendMail).toHaveBeenCalled();
    });

    test('should return validation errors', async () => {
        const mockUser = {
            username: '',
            email: 'invalid-email',
            password: 'pw',
            mobile: '',
            countryCode: 'US',
            accountType: 'standard',
            license: '',
        };

        // const validationError = {
        //     details: [
        //         { message: '"username" is not allowed to be empty' },
        //         { message: '"email" must be a valid email' },
        //         { message: '"password" length must be at least 6 characters long' },
        //         { message: '"mobile" is not allowed to be empty' },
        //         { message: '"license" is not allowed to be empty' },
        //     ],
        // };

        const registerValidationSchema = { validate: jest.fn().mockReturnValue(registerValidationSchema) };

        // Replace the registerValidationSchema in the controller with the mock
        jest.mock('../middleware/validation', () => ({
            registerValidationSchema: registerValidationSchema,
        }));

        const response = await request(app)
            .post('/register')
            .send(mockUser);

        expect(response.status).toBe(400);
        expect(response.body.errors).toHaveLength(4); // Check for the number of validation errors
    });

    test('should return error if user already exists', async () => {
        const mockUser = {
            username: 'testuser',
            email: 'test@example.com',
            password: 'password123',
            mobile: '1234567890',
            countryCode: 'US',
            accountType: 'standard',
            license: 'AB123456',
        };

        User.findOne.mockResolvedValue(mockUser); // Mock existing user

        const response = await request(app)
            .post('/register')
            .send(mockUser);
console.log(response,'response');
        expect(response.status).toBe(400);
        expect(response.body.message).toBe('User exists');
    });

    test('should handle server errors gracefully', async () => {
        const mockUser = {
            username: 'testuser',
            email: 'test@example.com',
            password: 'password123',
            mobile: '1234567890',
            countryCode: 'US',
            accountType: 'standard',
            license: 'AB123456',
        };

        User.findOne.mockResolvedValue(null); // No existing user
        User.prototype.save.mockRejectedValue(new Error('Database error')); // Simulate a save error

        const response = await request(app)
            .post('/register')
            .send(mockUser);

        expect(response.status).toBe(500);
        expect(response.body.message).toBe('Error registering user');
    });
});
