const jwt = require('jsonwebtoken');
const response = require('../helpers/response');
const verifyTokenAndRole = (allowedRoles) => { 
    return (req, res, next) => {
        const Bearertoken = req.header('Authorization');
        const token = Bearertoken.split(' ')[1];
        if (!token) return response.UnauthorizedError(res, res.__('Access_denied'));
        try { 
            const verified = jwt.verify(token, process.env.JWT_SECRET);
           
            if (!allowedRoles.includes(verified.role)) {
                return response.UnauthorizedError(res, res.__('Access_denied_permissions'));
            }
            req.user = verified;
            next();
        } catch (error) {
           
            return response.error(res, res.__('server_error'), error.message);
        }
    }
}

module.exports = verifyTokenAndRole;
