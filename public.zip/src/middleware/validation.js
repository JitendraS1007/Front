const Joi = require('joi');

const timeFormatRegex = /^([01]\d|2[0-3]):([0-5]\d)$/;
const MenuItemSchema = Joi.object({
    name: Joi.string().required().messages({
        'string.empty': 'Name is required',
        'any.required': 'Name is required'
    }),
    price: Joi.number().positive().required().messages({
        'number.base': 'Price must be a number',
        'number.positive': 'Price must be a positive number',
        'any.required': 'Price is required'
    }),
    quantity: Joi.number().positive().required().messages({
        'number.base': 'quantity must be a number',
        'number.positive': 'quantity must be a positive number',
        'any.required': 'quantity is required'
    }),
    foodtype: Joi.number().valid(1, 2).required().messages({
        'number.base': 'foodtype must be a number',
        'any.only': 'foodtype must be either 1 or 2',
        'any.required': 'foodtype is required'
    }),
    image: Joi.any().optional(),
    description:Joi.any().optional()
    // restaurant:Joi.any().optional()
});

const restaurantSchema = Joi.object({
    name: Joi.string().required().messages({
        'string.empty': 'Name is required',
        'any.required': 'Name is required'
    }),
    address: Joi.string().required().messages({
        'string.empty': 'address is required',
        'any.required': 'address is required'
    }),
    pincode: Joi.string().required().pattern(/^[1-9][0-9]{5}$/).messages({
        'string.empty': 'Pincode is required',
        'string.pattern.base': 'Invalid pincode',
        'any.required': 'Pincode is required'
    }),
    openingtime: Joi.date().iso().required().messages({
        'date.format': 'Opening time must be in ISO 8601 format (YYYY-MM-DDTHH:mm:ss.sssZ)',
        'any.required': 'Opening time is required'
    }),
    email: Joi.string().email({ tlds: { allow: false } }).max(100).optional(),
    phone_number: Joi.string().max(20).optional(),
    closingtime: Joi.date().iso().required().custom((value, helpers) => {
        const openingtime = helpers.state.ancestors[0].openingtime;
        if (new Date(value) <= new Date(openingtime)) {
            return helpers.message('Closing time must be after opening time');
        }
        return value;
    }).messages({
        'date.format': 'Closing time must be in ISO 8601 format (YYYY-MM-DDTHH:mm:ss.sssZ)',
        'any.required': 'Closing time is required'
    }),
    image: Joi.any().optional()
});

const registerValidationSchema = Joi.object({
    username: Joi.string()
        .alphanum()
        .min(3)
        .max(30)
        .required()
        .messages({
            'string.empty': 'Username is required',
            'string.min': 'Username must be at least 3 characters long',
            'string.max': 'Username cannot be longer than 30 characters',
        }),

    email: Joi.string()
        .email()
        .required()
        .messages({
            'string.email': 'Invalid email format',
            'string.empty': 'Email is required',
        }),

    password: Joi.string()
        .min(6)
        .required()
        .messages({
            'string.empty': 'Password is required',
            'string.min': 'Password must be at least 6 characters long',
        }),

    mobile: Joi.string()
        .pattern(/^[0-9]+$/)
        .min(10)
        .max(15)
        .required()
        .messages({
            'string.empty': 'Mobile number is required',
            'string.pattern.base': 'Mobile number must contain only digits',
            'string.min': 'Mobile number must be at least 10 digits',
            'string.max': 'Mobile number cannot be longer than 15 digits',
        }),

    countryCode: Joi.string()
        .pattern(/^\+\d+$/) // Ensures country code starts with '+'
        .required()
        .messages({
            'string.empty': 'Country code is required',
            'string.pattern.base': 'Country code must start with + followed by digits',
        }),

    accountType: Joi.number()
        .valid(1, 2, 3, 4) // Accept only valid account types
        .required()
        .messages({
            'any.required': 'Account type is required',
            'any.only': 'Account type must be 1, 2, 3, or 4',
        }),

    // License is required only if accountType is 3
    license: Joi.string()
        .when('accountType', {
            is: 3, // Only validate if accountType is 3
            then: Joi.string().required().messages({
                'string.empty': 'License is required for account type 3',
            }),
            otherwise: Joi.forbidden(), // If accountType is not 3, do not allow license
        }),
        emailVerified:Joi.any().optional(),
        web: Joi.any().optional()
});

const reviewValidationSchema = Joi.object({
    restaurant_id: Joi.string().required().messages({
        'any.required': 'Restaurant ID is required',
        'string.base': 'Restaurant ID must be a valid string'
    }),
    rating: Joi.number().min(1).max(5).required().messages({
        'any.required': 'Rating is required',
        'number.base': 'Rating must be a number',
        'number.min': 'Rating must be at least 1',
        'number.max': 'Rating cannot be more than 5'
    }),
    review_text: Joi.string().allow('').optional() // Optional field
});

const deliveryAddressSchema = Joi.object({
    address_line1: Joi.string().required().messages({
        'string.empty': 'Address Line 1 is required',
        'any.required': 'Address Line 1 is required'
    }),
    address_line2: Joi.string().optional().allow(null, ''),
    city: Joi.string().required().messages({
        'string.empty': 'City is required',
        'any.required': 'City is required'
    }),
    state: Joi.string().required().messages({
        'string.empty': 'State is required',
        'any.required': 'State is required'
    }),
    postal_code: Joi.string().required().messages({
        'string.empty': 'Postal code is required',
        'any.required': 'Postal code is required'
    }),
    country: Joi.string().required().messages({
        'string.empty': 'Country is required',
        'any.required': 'Country is required'
    }),
    contact_number: Joi.string().required().messages({
        'string.empty': 'Contact number is required',
        'any.required': 'Contact number is required'
    }),
    delivery_instructions: Joi.string().optional().allow(null, ''),
    is_default: Joi.boolean().optional()
});

module.exports = {
    restaurantSchema ,MenuItemSchema ,registerValidationSchema ,reviewValidationSchema ,deliveryAddressSchema
};
