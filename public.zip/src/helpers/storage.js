const multer = require('multer');
const path = require('path');
let pathfile = path.join(__dirname,'../../public/uploads/images')
const multerS3 = require('multer-s3');
const s3 = require('../helpers/config');
require('dotenv').config();
const storage = multer.diskStorage({
    
    destination: (req, file, cb) => {
        cb(null, pathfile);  
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const fileFilter = (req, file, cb) => {
    const allowedFileTypes = /jpeg|jpg|png|gif/;
    const mimeType = allowedFileTypes.test(file.mimetype);
    const extname = allowedFileTypes.test(path.extname(file.originalname).toLowerCase());

    if (mimeType && extname) {
        return cb(null, true);
    } else {
        cb('Error: Only image files (jpeg, jpg, png, gif) are allowed!');
    }
};

// const upload = multer({
//     storage: storage,
//     fileFilter: fileFilter,
//     limits: { fileSize: 1024 * 1024 * 5 }
// }).any();

const Upload = multer({
    storage: multerS3({
      s3: s3,
      bucket: process.env.AWS_Bucket, // Replace with your bucket name
      acl: 'public-read', // Set appropriate ACL
      key: (req, file, cb) => {
        cb(null, Date.now().toString() + '-' + file.originalname); // File name
      }
    })
  });
module.exports = Upload;
