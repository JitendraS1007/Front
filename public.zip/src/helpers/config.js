const AWS = require('aws-sdk');
require('dotenv').config();
AWS.config.update({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID, // Your AWS Access Key
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY, // Your AWS Secret Key
  region: process.env.AWS_REGION // Your AWS Region
});

const s3 = new AWS.S3();

module.exports = s3;