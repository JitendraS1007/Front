const mongoose = require('mongoose');

const MenuItemSchema = new mongoose.Schema({
    name: { type: String, required: true },
    price: { type: Number, required: true },
    quantity: { type: Number, required: true },
    image: { type: String,  default: null},
    foodtype: { type: Number, required: true, enum: [1, 2]}, // e.g., 1 => 'veg', 2=>'non-veg'
    description: { type: String, required: true },
    status: { type: Number, default: 1,enum: [1, 2]},  // 1 => Active , 2=> inactive
    restaurant: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant', required: true } 
}, {
    timestamps: true
});

module.exports = mongoose.model('MenuItem', MenuItemSchema);
