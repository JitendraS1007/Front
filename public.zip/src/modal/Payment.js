const mongoose = require('mongoose');
const Order = require('../modal/Order');
const User = require('../modal/User');
const paymentSchema = new mongoose.Schema({
    order_id: {
        type: mongoose.Schema.Types.ObjectId, 
        required: true,
        ref: 'Order',
    },
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'User', 
    },
    amount: {
        type: mongoose.Schema.Types.Decimal128,
        required: true,
    },
    payment_method: {
        type: String,
        enum: ['Card', 'Cash', 'Online Wallet'], 
        required: true,
    },
    payment_status: {
        type: String,
        enum: ['Success', 'Failed'], 
        required: true,
    },
    payment_time: {
        type: Date,
        default: Date.now, 
    },
}, { timestamps: true }); 


const Payment = mongoose.model('Payment', paymentSchema);

module.exports = Payment;
