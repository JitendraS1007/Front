const mongoose = require('mongoose');

const deliveryAddressSchema = new mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User', 
        required: true
    },
    address_line1: {
        type: String,
        required: true
    },
    address_line2: {
        type: String,
        default: null
    },
    city: {
        type: String,
        required: true
    },
    state: {
        type: String,
        required: true
    },
    postal_code: {
        type: String,
        required: true
    },
    country: {
        type: String,
        required: true
    },
    contact_number: {
        type: String,
        required: true
    },
    delivery_instructions: {
        type: String,
        default: null
    },
    is_default: {
        type: Boolean,
        default: false
    },
    created_at: {
        type: Date,
        default: Date.now
    },
    updated_at: {
        type: Date,
        default: Date.now
    }
});

deliveryAddressSchema.pre('save', function (next) {
    this.updated_at = Date.now();
    next();
});

const DeliveryAddress = mongoose.model('DeliveryAddress', deliveryAddressSchema);

module.exports = DeliveryAddress;
