const mongoose = require('mongoose');

// Define the OrderItem schema
const orderItemSchema = new mongoose.Schema({
    order_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Order', required: true },
    menu_item_id: { type: mongoose.Schema.Types.ObjectId, ref: 'MenuItem', required: true },
    quantity: { type: Number, required: true },
    price: { type: mongoose.Schema.Types.Decimal128, required: true },
    total_price: { type: mongoose.Schema.Types.Decimal128, required: true }, // Price * Quantity
    restaurant_id: { type: mongoose.Schema.Types.ObjectId, required: true, ref: 'Restaurant', index: true, }
}, { timestamps: true });

const OrderItem = mongoose.model('OrderItem', orderItemSchema);

module.exports = OrderItem;
