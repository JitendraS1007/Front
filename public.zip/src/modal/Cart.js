const mongoose = require('mongoose');
const MenuItem = require('../modal/MenuItem');
const User = require('../modal/User');
// Create a schema for cart items

const cartItemSchema = new mongoose.Schema({
    menu_item_id: { type: mongoose.Schema.Types.ObjectId, required: true, ref: MenuItem },
    quantity: { type: Number, required: true, min: 1  },
    
    // price: { type: Number, required: true }
});

// Create a schema for the cart
const cartSchema = new mongoose.Schema({
    user_id: { type: mongoose.Schema.Types.ObjectId, required: true, ref: User },
    restaurant: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant', required: true } ,
    items: [cartItemSchema],
    // total_price: { type: Number, default: 0  },
    created_at: { type: Date, default: Date.now }, 
    updated_at: { type: Date, default: Date.now }
    
});

// Middleware to update total price whenever the cart is updated
// cartSchema.pre('save', function(next) {
//     this.total_price = this.items.reduce((total, item) => {
//         return total + (item.price * item.quantity);
//     }, 0);
//     this.updated_at = Date.now(); 
//     next();
// });

// Create the Cart model
const Cart = mongoose.model('Cart', cartSchema);

module.exports = Cart;