const mongoose = require('mongoose');

const restaurantSchema = new mongoose.Schema({
    name: { type: String, required: true },
    address: { type: String, required: true },
    pincode: { type: String, required: true },
    openingtime: { type: String, required: true },
    closingtime: { type: String, required: true },
    phone_number: { type: String, maxlength: 20 }, 
    email: { type: String, maxlength: 100 },
    image: { type: String ,default: null },
    ownerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    status: { type: Number, default: 1,enum: [1, 2]},  // 1 => Active , 2=> inactive
}, {
    timestamps: true
});

module.exports = mongoose.model('Restaurant', restaurantSchema);
