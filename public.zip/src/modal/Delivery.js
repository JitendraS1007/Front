const mongoose = require('mongoose');

const deliverySchema = new mongoose.Schema({
    order_id: {
        type: mongoose.Schema.Types.ObjectId, 
        required: true,
        ref: 'Order',
    },
    driver_id: {
        type: mongoose.Schema.Types.ObjectId, 
        required: true,
        ref: 'User', 
    },
    pickup_time: {
        type: Date,
        default: Date.now,

    },
    delivery_time: {
        type: Date
    },
    delivery_status: {
        type: String,
        enum: ['Pending', 'On the Way', 'Delivered', 'Failed'], 
        default: 'Pending', 
    },
}, { timestamps: true });
const Delivery = mongoose.model('Delivery', deliverySchema);

module.exports = Delivery;
