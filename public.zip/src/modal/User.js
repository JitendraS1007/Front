const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    username: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    mobile: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    countryCode: { type: String, required: true },
    emailVerified: { type: Boolean, default: false }, 
    accountType: { type: Number, required: true, enum: [1, 2, 3, 4]},
    license: { type: String, required: function() { return this.accountType === 3; }, default: null },
    resetToken: { type: String, default: null},
    resetTokenExpiration: { type: Date, default: null },
    createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('User', UserSchema);

