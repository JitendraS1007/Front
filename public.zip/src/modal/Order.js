const mongoose = require('mongoose');
const mongooseSequence = require('mongoose-sequence')(mongoose);

const orderSchema = new mongoose.Schema({
    order_id: {
        type: Number,
        unique: true,  
    },
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'User',
        index: true,
    },
    restaurant_id: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'Restaurant',
        index: true,
    },
    total_price: {
        type: mongoose.Types.Decimal128,
        required: true,
    },
    status: {
        type: String,
        enum: ['Pending', 'Preparing', 'Picked Up', 'Delivered', 'Cancelled'],
        default: 'Pending',
    },
    payment_type: { type: Number, required: true, enum: [1, 2]}, // 1 cash on delivery  // 2 online
    payment_status: {
        type: String,
        enum: ['Paid', 'Unpaid'],
        default: 'Unpaid',
    },
    order_time: {
        type: Date,
        default: Date.now,
    },
    delivery_address_id: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'DeliveryAddress',
        index: true,
    }
}, { timestamps: true }); 


orderSchema.plugin(mongooseSequence, { inc_field: 'order_id' });


const Order = mongoose.model('Order', orderSchema);

module.exports = Order;
