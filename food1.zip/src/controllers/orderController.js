const Order = require('../modal/Order');
const OrderItem = require('../modal/OrderItem');
const Cart = require('../modal/Cart');
const response = require('../helpers/response');
const MenuItem = require('../modal/MenuItem');
const {transport  ,getOrderHtml} = require('../services/emailService')
const DeliveryAddress = require('../modal/DeliveryAddress');
const { parse } = require('dotenv');
exports.createOrder = async (req, res) => {
    const session = await Order.startSession();
    let transactionCommitted = false;
    session.startTransaction();
    try {
        const userId = req.user.id; 
        const cart = await Cart.findOne({ user_id: userId }).populate('items.menu_item_id');

        if (!cart || cart.items.length === 0) {
            return response.notFoundError(res, res.__('Cart_is_empty'));
        }

        const user_address = await DeliveryAddress.findOne({ _id: req.body.delivery_address_id });
        if (!user_address) {
            return response.notFoundError(res, res.__('address_not_found'));
        }

        let totalPrice = 0;
        let restaurant_id = '';
        const orderItems = await Promise.all(cart.items.map(async item => {
            const menuItem = await MenuItem.findById(item.menu_item_id);
            if (!menuItem) {
                return response.notFoundError(res, res.__('Menu_item_not_found:'));
            }
            restaurant_id = menuItem.restaurant;
            const singleItemPrice =  (parseInt(menuItem.price) / parseInt(menuItem.quantity) )
            const itemTotalPrice =singleItemPrice * item.quantity;
            totalPrice += itemTotalPrice;
            return {
                menu_item_id: menuItem._id,
                quantity: item.quantity,
                price: singleItemPrice,
                total_price: itemTotalPrice,
                restaurant_id: menuItem.restaurant
            };
        }));

        const newOrder = new Order({
            user_id: userId,
            total_price: totalPrice,
            status: 'Pending',
            restaurant_id: restaurant_id,
            delivery_address_id: req.body.delivery_address_id,
            payment_type: req.body.payment_type,
            payment_status: req.body.payment_status
        });

        await newOrder.save({ session });

        const savedOrderItems = await Promise.all(orderItems.map(async item => {
            const orderItem = new OrderItem({
                order_id: newOrder._id,
                menu_item_id: item.menu_item_id,
                quantity: item.quantity,
                price: item.price,
                total_price: item.total_price,
                restaurant_id: item.restaurant_id
            });
            return await orderItem.save({ session });
        }));

        await Cart.deleteOne({ user_id: userId }).session(session);
        await session.commitTransaction();
        transactionCommitted = true;

        const data = await getOrderHtml(savedOrderItems.map(item => item._id));
        await transport.sendMail({
            from: '"fooddeliver" <process.env.SENDER_MAIL>',
            to: req.user.email,
            subject: "Order Placed",
            html: data,
        });

        return response.successWithData(res, res.__('order_save_successfully'), savedOrderItems, 201);
    } catch (error) {
        if (!transactionCommitted) {
            await session.abortTransaction(); // Rollback transaction in case of an error
        }
        console.error('Error creating order:', error);
        return res.status(400).json({ message: error.message });
    } finally {
        session.endSession();
    }
};

exports.getOrder = async(req, res) => {
    try { 
        const { id } = req.query;
        const query = id ? { _id: id } : {};
            orders = await Order.find(query).populate({
            path: 'user_id',
            select: 'username email mobile countryCode'
        }).populate({
            path: 'restaurant_id',
            select: 'name location pincode'
        }).populate({
            path: 'delivery_address_id',
            select: 'address_line1 address_line2 city state postal_code country contact_number delivery_instructions latitude longitude type'
        });
        return response.successWithData(res, res.__('Order_retrieved_successfully'), orders, 200);
    } catch (error) {
        return response.error(res, res.__('server_error'), error.message);
    }
};
exports.getAllOrder = async(req,res)=>{
    try{
        const userId = req.user.id;
        const userRoleId = req.user.role
        let query = {};
        if (userRoleId === 1) {
            query = {};
        } else {
            const restaurants = await Restaurant.find({ owner_id: userId });
            const restaurantIds = restaurants.map(restaurant => restaurant._id);
            query = { restaurant_id: { $in: restaurantIds } };
        }
        const page = parseInt(req.query.page) || 1; 
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page - 1) * limit; 
        const orders = await Order.find(query)
                        .skip(skip)
            .           limit(limit)
                        .populate({
                            path: 'user_id',
                            select: 'username email mobile countryCode'
                        })
                        .populate({
                            path: 'restaurant_id',
                            select: 'name location pincode'
                        }).populate({
                            path: 'delivery_address_id',
                            select: 'address_line1 address_line2 city state postal_code country contact_number delivery_instructions latitude longitude type'
                        });
        const totalOrders = await Order.countDocuments(query);
        const totalPages = Math.ceil(totalOrders / limit);
        return response.successWithData(res, res.__('Order_retrieved_successfully'), {currentPage: page, totalPages: totalPages, totalOrders: totalOrders, orders: orders }, 201);
    } catch (error) {
        return response.error(res, res.__('server_error'), error.message);
    }

}

exports.deleteOrder = async(req, res) => {
    try {
        const deletedOrder = await Order.findByIdAndDelete(req.params.id);
        if (!deletedOrder) {
            return response.error(res, res.__('order_not_found'), null, 404);
        }
        return response.success(res, res.__('order_removed_from_cart_successfully'), 200);
    } catch (error) {
        return response.error(res, res.__('server_error'), error.message);
    }
};

exports.getOrderPayment = async(req,res) => {
    try{
        const getOrder = await Order.findById(req.params.id).select(' user_id total_price');
        if(getOrder){
            return response.successWithData(res, res.__('order_Price'), getOrder , 200);
        }else{
            return response.error(res, res.__('order_not_found'), null, 404);
        }
    }catch  (error){
        return response.error(res, res.__('server_error'), error.message);
    }
}