const Offer = require('../modal/Offer');
const Upload = require('../helpers/storage');
const path = require('path');
const fs = require('fs');
require('dotenv').config();
const response = require('../helpers/response');
exports.offerAdd = async (req, res) => {
    try {
        await new Promise((resolve, reject) => {
            Upload(req, res, (err) => {
                if (err) {
                    return reject({ message: err });
                }
                if (!req.files || req.files.length === 0) {
                    return reject({ message: 'No files uploaded.' });
                }
                resolve();
            });
        });
        const { name, description, type, rate, maxAmount ,minimumPurchase ,restaurant_id } = req.body;
        const existing_offer = await Offer.findOne({ name: name , restaurant:restaurant_id});
        if (existing_offer) {
            return response.validationError(res, res.__('Offer_name_will_be_uniq'));
        }
        let image = null;
        if (req.files && req.files.length > 0) {
            image = req.files[0].filename;
        }
        const newoffer = new Offer({ 
        name, description, type, rate, maxAmount ,minimumPurchase , image ,restaurant:restaurant_id });
        const savedOffer = await newoffer.save();
        return response.successWithData(res, res.__('offer_added_sucoffercessfully'), savedOffer, 201);
    } catch (error) {
        console.log(error);
        return response.error(res, res.__('server_error'), error.message);
    }
};