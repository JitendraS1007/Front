const response = require('../helpers/response');
const Payment = require('../modal/Payment');
exports.getInvoice = async (req, res) => {
    // try {
    //     const { order_id } = req.query;
    //     if (!order_id) {
    //         return response.error(res, res.__('order_id_not_found'), null, 404);
    //     }
    //     const payment = await Payment.findOne({ order_id })
    //                     .populate({
    //                         path: 'order_id',
    //                         populate: [
    //                             { path: 'user_id'  , select: 'name email mobile'}, 
    //                             { path: 'restaurant_id',select:'"name address email phone_number' }
    //                         ]
    //                     });
    //     if (!payment) {
    //         return response.validationError(res, res.__('Invoice_not_found'));
    //     }
    //     return response.successWithData(res, res.__('restaurant_List'), payment, 200);
    // }catch (error) {
    //     return response.error(res, res.__('server_error'), error.message);
    // }
    const { order_id } = req.query;

    if (order_id === '670be083903ebe0c479fae88') {
      return res.json({ order_id, total: 100.00 });
    }
  
    return res.status(404).json({ error: 'Invoice not found' });
}