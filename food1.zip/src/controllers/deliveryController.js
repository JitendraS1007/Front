const Delivery = require('../modal/Delivery');
const response = require('../helpers/response');
const {findNearestDriver ,deliveryStatus} = require('../helpers/functions');
const Order = require('../modal/Order');
const Restaurant = require('../modal/Restaurant');
const User = require('../modal/User');
const { transport , getDeliveryAssgin ,getDeliveryStatus } = require('../services/emailService')

exports.createDelivery = async (req, res) => {
    const { order_id } = req.body;
    try { 
        const existing_order = await Order.findOne({ _id: order_id });
        if (!existing_order) {
            return response.validationError(res, res.__('Order_not_exists'));
        }
        const restro = await Restaurant.findById(existing_order.restaurant_id) ;
        const existing_delivery = await Delivery.findOne({ order_id });
        if (existing_delivery) {
            return response.validationError(res, res.__('Order_already_assign'));
        }
        const drivers = await User.find({accountType:3});

        const { nearestDriver, minDistance } = findNearestDriver(drivers, restro.location.coordinates);
        let driver_id = '';
        if (nearestDriver) {
           driver_id =nearestDriver._id
            console.log(`Nearest Driver: ${nearestDriver.username}, Distance: ${minDistance.toFixed(2)} km`);
        } else {
            return response.notFoundError(res, res.__('No_drivers_found'));
        }
        const newDelivery = new Delivery({ order_id, driver_id});
        const delivery = await newDelivery.save();
        const data = await getDeliveryAssgin(nearestDriver.username,order_id);
        transport.sendMail({
            from: '"fooddevliver " <process.env.SENDER_MAIL>',
            to: nearestDriver.email,
            subject: `Order assign`,
            html: data, 
        }); 
        return response.successWithData(res, res.__('order_assign_sucessfully'), delivery, 201);
       
    } catch (error) {
        console.log(error)
        return response.error(res, res.__('server_error'), error.message);
    }
};

exports.updateDeliveryStatus = async (req, res) => {
  
    const { deliveryId } = req.params;
    const { delivery_status } = req.body;
    try {
        const existing_delivery = await Delivery.findById(deliveryId);
        if (!existing_delivery) {
            return response.notFoundError(res, res.__('Delivery_not_found'));
        }
        const existing_order = await Order.findById(existing_delivery.order_id);
        if (existing_order && existing_order.payment_status === 'paid' && delivery_status == 4) {
            if (delivery_status === 4) {
                existing_delivery.delivery_time = Date.now();
            } else {
                return response.validationError(res, res.__('Payment_pending'));
            }
        }else if(existing_order && existing_order.payment_status === 'Unpaid' && delivery_status == 4){
            return response.validationError(res, res.__('Payment_pending'));
        }
        return;
        if(existing_delivery.delivery_status == delivery_status-1){
            existing_delivery.delivery_status = delivery_status;
            if(delivery_status==2){
                existing_delivery.pickup_time =  Date.now();
            }
            const updatedDelivery = await existing_delivery.save();
            
            // const data = await getDeliveryStatus(nearestDriver.username,deliveryStatus[delivery_status]);
            // transport.sendMail({
            //     from: '"fooddevliver " <process.env.SENDER_MAIL>',
            //     to: nearestDriver.email,
            //     subject: `Order assign`,
            //     html: data, 
            // }); 
            return response.successWithData(res, res.__(`Delivery_status_updated_${deliveryStatus[delivery_status]}`), updatedDelivery, 200);
        }else{
            return response.validationError(res, res.__('Please_select_correct_status'));
        }
        
    } catch (error) {
        console.error(error);
        return response.error(res, res.__('server_error'), error.message);
    }
};
exports.getDeliveryDetails = async (req, res) => {
    const { deliveryId } = req.params;
    try {
        const delivery = await Delivery.findById(deliveryId)
            .populate('order_id', 'order')
            .populate('driver_id', 'name vehicle_number');

        if (!delivery) {
            return response.notFoundError(res, res.__('Delivery_not_found'));
        }
        return response.success(res, res.__('Delivery_status_updated_successfully'), delivery, 200);
    } catch (error) {
        return response.error(res, res.__('server_error'), error.message);
    }
};
