const Restaurant = require('../modal/Restaurant');
const moment = require('moment');
const { isValidTime, validateTimes } = require('../helpers/functions');
const response = require('../helpers/response');
const { restaurantSchema } = require('../middleware/validation');
const Upload = require('../helpers/storage');
const path = require('path');
const fs = require('fs');
require('dotenv').config();
exports.resturantAdd = async (req, res) => {
    try {
        await new Promise((resolve, reject) => {
            Upload(req, res, (err) => {
                if (err) {
                    return reject({ message: err });
                }
                if (!req.files || req.files.length === 0) {
                    return reject({ message: 'No files uploaded.' });
                }
                resolve();
            });
        });

        const { name, address, pincode, openingtime, closingtime ,phone_number ,email ,latitude, longitude ,type } = req.body;
        if(!validateTimes(openingtime ,closingtime)){
            return response.validationError(res, 'time does correct format');
        }
        const ownerId = req.user.id;
        // Validate request body
        const { error } = restaurantSchema.validate(req.body, { abortEarly: false });
        if (error) {
            const errMessages = error.details.map(err => ({ message: err.message }));
            return response.validationError(res, errMessages);
        }
        const existing_restaurant = await Restaurant.findOne({ $or: [ { name: name }, { email: email },   { phone_number: phone_number } ]});
        if (existing_restaurant) {
            return response.validationError(res, res.__('Restaurant_name_email_mobile_will_be_uniq'));
        }
        let image = null;
        if (req.files && req.files.length > 0) {
            image = req.files[0].filename;
        }
        
        const newRestaurant = new Restaurant({ 
            name, address, pincode, openingtime, closingtime, ownerId, image ,phone_number ,email , location: { // Properly structured location
                type: type,
                coordinates: [longitude, latitude],
            }
        });
        
        const savedRestaurant = await newRestaurant.save();
        return response.successWithData(res, res.__('restaurant_added_successfully'), savedRestaurant, 201);
    } catch (error) {
        console.log(error);
        if (!res.headersSent) {
            return response.error(res, res.__('server_error'), error.message);
        }
    }
};

exports.resturantList = async (req, res) => {
    try {
        const { name } = req.query;
        let query = {};
        const { page = 1, limit = process.env.Limit } = req.query; // Default to page 1 and limit of 10
        const pageNum = parseInt(page, 10);
        const limitNum = parseInt(limit, 10);
        const skip = (pageNum - 1) * limitNum;
        if (name) {
            query.name = { $regex: name, $options: 'i' };
        }
        if(req.user.role == 2){
            query.ownerId = req.user.id;
        }
        const imageBasePath = process.env.APP_URL+'uploads/images/';
        const restaurants = await Restaurant.find( query  )
                                            .sort({ createdAt: -1 })
                                            .skip(skip)
                                            .limit(limitNum);
        const restaurantList = restaurants.map(restaurant => {
            return {
                ...restaurant._doc, // Spread the restaurant document to keep all original fields
                image: `${imageBasePath}${restaurant.image}`, // Concatenate the base path
            };
            });
        const totalCount = await Restaurant.countDocuments(query);
        const totalPages = Math.ceil(totalCount / limitNum);
        
        return response.successWithData(res, res.__('restaurant_List'), { restaurantList, totalPages, currentPage: pageNum, totalCount }, 200);
    }catch (error) {
        return response.error(res, res.__('server_error'), error.message);
    }
}
exports.restroEdit = async (req, res) => {
    try {
        const { restroId } = req.params;
        const existingrestro = await Restaurant.findById(restroId);
        if (!existingrestro) {
            return response.error(res, res.__('restaurant_not_found'), null, 404);
        }
        new Promise((resolve, reject) => {
            Upload(req, res, (err) => {
                if (err) {
                    return reject({ message: err });
                }
                resolve();
            });
        })
        .then(async () => {
            const { name, location, openingtime, closingtime, pincode ,email ,phone_number ,latitude, longitude ,type } = req.body;
            const existing_restaurant = await Restaurant.findOne({$or: [ { name: name }, { email: email }, { phone_number: phone_number } ], _id: { $ne: restroId }});
            if (existing_restaurant) {
                return response.validationError(res, res.__('Restaurant_name_email_mobile_will_be_uniq'));
            }
            existingrestro.name         = name || existingrestro.name;
            existingrestro.location     = location || existingrestro.location;
            existingrestro.pincode      = pincode || existingrestro.pincode;
            existingrestro.openingtime  = openingtime || existingrestro.openingtime;
            existingrestro.closingtime  = closingtime || existingrestro.closingtime;
            existingrestro.latitude     = latitude || existingrestro.latitude;
            existingrestro.longitude    = longitude || existingrestro.longitude;
            existingrestro.type         = type || existingrestro.type;
            if (req.files && req.files.length > 0) {
                const uploadedImage = req.files[0].filename;
                if (existingrestro.image) {
                    const oldImagePath = path.join(__dirname, '../../public/uploads/images/restaurants', existingrestro.image);
                    if (fs.existsSync(oldImagePath)) {
                        fs.unlinkSync(oldImagePath);
                    }
                }
                existingrestro.image = uploadedImage;
            }
            const updatedRestro = await existingrestro.save();
            return response.successWithData(res, res.__('restaurant_updated_successfully'), updatedRestro, 200);
        })
        .catch(err => {
            return res.status(400).json({ message: err.message });
        });

    } catch (error) {
        return response.error(res, res.__('server_error'), error.message);
    }
};
exports.resturnatStatusUpdate = async (req,res)=>{
    try{
        const { id } = req.body;
        const updatedRestaurant = await Restaurant.findOneAndUpdate(
            { _id: id },
            [
                { 
                    $set: { status: { $cond: { if: { $eq: ["$status", 1] }, then: 0, else: 1 } } }
                }
            ],
            { new: true }
        );
        if (!updatedRestaurant) {
            return response.error(res, res.__('restaurant_not_found'), null, 404);
        }
        return response.success(res,(updatedRestaurant.status)?res.__('restaurant_activate_successfully'):res.__('restaurant_deactivate_successfully'), 200);
    }catch(error){
        return response.error(res, res.__('server_error'), error.message);
    }
}
