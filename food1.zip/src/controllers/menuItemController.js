const express = require('express');
const upload = require('../helpers/storage');
const MenuItem = require('../modal/MenuItem');
const Restaurant = require('../modal/Restaurant');
const response = require('../helpers/response');
const { MenuItemSchema } = require('../middleware/validation');
const mongoose = require('mongoose');
exports.MenuAdd = async (req, res) => {
    try {
        await new Promise((resolve, reject) => {
            upload(req, res, (err) => {
                if (err) return reject({ message: err });
                if (!req.files || req.files.length === 0) {
                    return reject({ message: 'No files uploaded.' });
                }
                resolve();
            });
        });
        const { name, price, quantity, foodtype, description ,restaurant_id} = req.body;
        const ownerId = req.user.id;
        if (await MenuItem.findOne({ name })) {
            return response.validationError(res, res.__('Menu_already_added'));
        }
        const { error } = MenuItemSchema.validate(req.body, { abortEarly: false });
        if (error) {
            const errMessages = error.details.map(err => ({ message: err.message }));
            return response.validationError(res, errMessages);
        }
        const existingRestaurant = await Restaurant.findById(restaurant_id);
        console.log(existingRestaurant,restaurant_id,'existingRestaurant');
        if (!existingRestaurant) {
            return response.error(res, res.__('restaurant_not_found'), null, 404);
        }
        const image = req.files && req.files.length > 0 ? req.files[0].filename : null;
        const newMenu = new MenuItem({ name, price, quantity, description, foodtype, image, ownerId, restaurant: restaurant_id });
        const savedMenu = await newMenu.save();
        return response.successWithData(res, res.__('Menu_added_successfully'), savedMenu, 201);
        
    } catch (error) {
        console.error(error);
        return response.error(res, res.__('server_error'), error.message);
    }
};

exports.MenuList = async (req, res) => {
    try {
        const { restaurantId, name } = req.params;
        let query = {};
        let restaurant = [];
        const imageBasePath = process.env.APP_URL+'uploads/images/';
        if (restaurantId) {
             restaurant = await Restaurant.findById(restaurantId);
            if (!restaurant) {
                return response.error(res, res.__('restaurant_not_found'), 404);
            }
            query.restaurant = restaurantId;
        } else if (name) {
            query.name = { $regex: name, $options: 'i' }; // Case-insensitive search
        }
        const menu = await MenuItem.find(query)
            .select('_id name price quantity description image foodtype restaurant');
            const MenuList = menu.map(item => {
                return {
                    ...item._doc, // Spread the restaurant document to keep all original fields
                    image: `${imageBasePath}${item.image}`, // Concatenate the base path
                };
                });
        return response.successWithData(res, (menu.length)?res.__('menu_List'):res.__('menu_List_empty'), {menu:MenuList, restaurant:restaurant}, 200);
    } catch (error) {
        return response.error(res, res.__('server_error'), error.message);
    }
};

exports.MenuEdit = async (req, res) => {
    try {
        const { menuId } = req.body.menuId;
        const existingMenuItem = await MenuItem.findById(menuId);
        if (!existingMenuItem) {
            return response.error(res, res.__('menuItem_not_found'), null, 404);
        }
        console.log(existingMenuItem);
        new Promise((resolve, reject) => {
            upload(req, res, (err) => {
                if (err) {
                    return reject({ message: err });
                }
                resolve();
            });
        })
        .then(async () => {
            const { name, price, quantity, foodtype, description } = req.body;
            existingMenuItem.name           = name || existingMenuItem.name;
            existingMenuItem.price          = price || existingMenuItem.price;
            existingMenuItem.quantity       = quantity || existingMenuItem.quantity;
            existingMenuItem.foodtype       = foodtype || existingMenuItem.foodtype;
            existingMenuItem.description    = description || existingMenuItem.description;
            if (req.files && req.files.length > 0) {
                const uploadedImage = req.files[0].filename;
                if (existingMenuItem.image) {
                    const oldImagePath = path.join(__dirname, '../../public/uploads/images/dishes', existingMenuItem.image);
                    if (fs.existsSync(oldImagePath)) {
                        fs.unlinkSync(oldImagePath);
                    }
                }
                existingMenuItem.image = uploadedImage;
            }
            const updatedMenuItem = await existingMenuItem.save();
            return response.success(res, res.__('MenuItem_updated_successfully'), updatedMenuItem, 200);
        })
        .catch(err => {
            return res.status(400).json({ message: err.message });
        });

    } catch (error) {
        console.log(error,'error');
        return response.error(res, res.__('server_error'), error.message);
    }

}
exports.MenuStatusUpdate = async (req, res) => {
    try{
        const { restroId } = req.params;
        const updatedMenuItem = await MenuItem.findOneAndUpdate(
            { _id: restroId },
            [
                { 
                    $set: { status: { $cond: { if: { $eq: ["$status", 1] }, then: 0, else: 1 } } }
                }
            ],
            { new: true }
        );
        if (!updatedMenuItem) {
            return response.error(res, res.__('MenuItem_not_found'), null, 404);
        }
        return response.success(res, res.__('MenuItem_status_updated_successfully'), updatedMenuItem, 200);
    }catch(error){
        return response.error(res, res.__('server_error'), error.message);
    }
}