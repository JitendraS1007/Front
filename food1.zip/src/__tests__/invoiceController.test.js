const request = require('supertest');
const app = require('../../app'); // Adjust the path if necessary
const Payment = require('../modal/Payment'); // Adjust path if necessary
const response = require('../helpers/response');

jest.mock('../modal/Payment'); // Mock the Payment model
jest.mock('../helpers/response'); // Mock the response helper

describe('Invoice Controller', () => {
    afterEach(() => {
        jest.clearAllMocks(); // Clear mocks after each test
    });
    it('when pass id ', async()=>{
        const response  = await request(app).get('/api/invoice?order_id=670be083903ebe0c479fae88');
        expect(response.status).toBe(200); 
    });
    it('should return error if order_id is not provided', async () => {
        const response = await request(app).get('/api/invoice'); // Adjust the endpoint if necessary
console.log(JSON.parse(response.text).error,'error')
        expect(response.error).toHaveBeenCalledWith(
           
            expect.any('Invoice not found'),
           
        );
        expect(response.status).toBe(404);
    });

    // it('should return error if invoice is not found', async () => {
    //     const orderId = '12345';
    //     const res = await request(app).get(`/api/invoice?order_id=${orderId}`);

    //     Payment.findOne.mockResolvedValue(null); // Simulate no payment found
    //     response.validationError.mockImplementation((res, message) => {
    //         return res.status(404).json({ message });
    //     });

    //     const responseMessage = 'Invoice not found';
    //     const expectedResponse = { message: responseMessage };
    //     const responseCall = jest.fn().mockReturnValue(expectedResponse);
    //     response.validationError = responseCall;

    //     const result = await request(app).get(`/api/invoice?order_id=${orderId}`);
        
    //     expect(response.validationError).toHaveBeenCalledWith(
    //         expect.anything(),
    //         responseMessage
    //     );
    //     expect(result.body).toEqual(expectedResponse);
    // });

    // it('should return invoice data when found', async () => {
    //     const orderId = '12345';
    //     const paymentData = {
    //         order_id: orderId,
    //         user_id: { name: 'John Doe', email: 'john@example.com', mobile: '1234567890' },
    //         restaurant_id: { name: 'Pizza Place', address: '123 Main St', email: 'pizza@example.com', phone_number: '9876543210' },
    //     };
        
    //     Payment.findOne.mockResolvedValue(paymentData); // Simulate found payment
        
    //     response.successWithData.mockImplementation((res, message, data) => {
    //         return res.status(200).json({ message, data });
    //     });

    //     const result = await request(app).get(`/api/invoice?order_id=${orderId}`);

    //     expect(response.successWithData).toHaveBeenCalledWith(
    //         expect.anything(),
    //         expect.any(String),
    //         paymentData,
    //         200
    //     );
    //     expect(result.status).toBe(200);
    //     expect(result.body).toEqual({ message: 'restaurant_List', data: paymentData }); // Adjust based on your actual response
    // });

    // it('should return server error on exception', async () => {
    //     const orderId = '12345';
    //     Payment.findOne.mockImplementation(() => {
    //         throw new Error('Database error');
    //     });

    //     const result = await request(app).get(`/api/invoice?order_id=${orderId}`);

    //     expect(response.error).toHaveBeenCalledWith(
    //         expect.anything(),
    //         expect.any(String),
    //         'Database error'
    //     );
    //     expect(result.status).toBe(500);
    // });
});
