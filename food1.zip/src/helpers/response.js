module.exports = {
    successWithData: (res, message, data = {}, statusCode = 200) => {
        return res.status(statusCode).json({
            success: true,
            message,
            data
        });
    },
    success: (res, message, statusCode = 200) => {
        return res.status(statusCode).json({
            success: true,
            message
        });
    },

    error: (res, message, error = null, statusCode = 500) => {
        return res.status(statusCode).json({
            success: false,
            message,
            error
        });
    },

    validationError: (res, message, statusCode = 400) => {
        return res.status(statusCode).json({
            success: false,
            message
        });
    },
    notFoundError:(res, message, statusCode = 404) => {
        return res.status(statusCode).json({
            success: false,
            message
        });
    },
    UnauthorizedError:(res, message, statusCode = 401) => {
        return res.status(statusCode).json({
            success: false,
            message
        });
    }
};
