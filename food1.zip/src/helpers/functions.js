function isValidTime(timeStr) {
    const regex = /^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/;
    return regex.test(timeStr);
}

function validateTimes(openingTime, closingTime) {
    if (!isValidTime(openingTime) || !isValidTime(closingTime)) {
        return false;
    }
    return openingTime < closingTime;
}
function haversineDistance(lon1 ,lat1,lon2, lat2) {
    const toRad = (value) => (value * Math.PI) / 180;
    const R = 6371; // Radius of the Earth in km

    const dLat = toRad(lat2 - lat1); 
    const dLon = toRad(lon2 - lon1);
    console.log(lat2 , lat1 , lon2 , lon1,'rc')
    const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);
       
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    
    return R * c; // Distance in km
}

function findNearestDriver(drivers, restaurantLocation) {
    let nearestDriver = null;
    let minDistance = Infinity;

    drivers.forEach(driver => {
       
        if (driver.location && driver.location.coordinates) {
            const driverCoords = driver.location.coordinates;
            const distance = haversineDistance(restaurantLocation[0],restaurantLocation[1], driverCoords[0],driverCoords[1]);
            if (distance < minDistance) {
                minDistance = distance;
                nearestDriver = driver;
            }
        }
    });

    return { nearestDriver, minDistance };
}

const deliveryStatus = {
    1: 'Pending',
    2: 'Accept',
    3: 'On the Way',
    4: 'Delivered',
    5: 'Failed'
};
module.exports = { isValidTime , validateTimes  ,haversineDistance ,findNearestDriver ,deliveryStatus} 
