const mongoose = require('mongoose');

const deliverySchema = new mongoose.Schema({
    order_id: {
        type: mongoose.Schema.Types.ObjectId, 
        required: true,
        ref: 'Order',
    },
    driver_id: {
        type: mongoose.Schema.Types.ObjectId, 
        required: true,
        ref: 'User', 
    },
    pickup_time: {
        type: Date,
        default: null,

    },
    delivery_time: {
        type: Date
    },
    delivery_status: {
        type: Number,
        enum: [1,2,3,4,5],  //1:'Pending',2:'Accept', 3:'On the Way', 4:'Delivered', 5:'Failed'
        default: 1, 
    },
}, { timestamps: true });
const Delivery = mongoose.model('Delivery', deliverySchema);

module.exports = Delivery;
