const mongoose = require('mongoose');
const Order = require('../modal/Order');
const User = require('../modal/User');
const paymentSchema = new mongoose.Schema({
    order_id: {
        type: mongoose.Schema.Types.ObjectId, 
        required: true,
        ref: 'Order',
    },
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'User', 
    },
    amount: {
        type: Number,
        required: true,
    },
    payment_method: {
        type: Number,
        enum: [1,2,3],  // 1:'Card', 2:'Cash', 3:'Online Wallet'
        required: true,
    },
    payment_status: {
        type: Number,
        enum: [0,1],  // 1: 'Success', 0:'Failed'
        required: true,
    },
    payment_time: {
        type: Date,
        default: Date.now, 
    },
}, { timestamps: true }); 


const Payment = mongoose.model('Payment', paymentSchema);

module.exports = Payment;
