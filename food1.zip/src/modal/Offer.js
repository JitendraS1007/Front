const mongoose = require('mongoose');
const mongooseSequence = require('mongoose-sequence')(mongoose);
const offerSchema = new mongoose.Schema({
    name: { type: String, required: true },
    description: { type: String, required: true },
    type:{ type: Number, required: true },
    rate:{ type: Number, required: true },
    maxAmount:{ type: Number, required: true },
    minimumPurchase:{ type: Number, required: true },
    image: { type: String,  default: null} ,
    restaurant: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant', required: true } ,
    status: { type: Number, default: 1,enum: [1, 2]}

}, { timestamps: true }); 


// orderSchema.plugin(mongooseSequence, { inc_field: 'order_id' });


const Offer = mongoose.model('Offer', offerSchema);

module.exports = Offer;