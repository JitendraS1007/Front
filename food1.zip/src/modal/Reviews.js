const mongoose = require('mongoose');

const reviewSchema = new mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId, 
        required: true,
        ref: 'User', 
    },
    restaurant_id: {
        type: mongoose.Schema.Types.ObjectId, 
        required: true,
        ref: 'Restaurant', 
    },
    rating: {
        type: Number,
        required: true,
        min: 1,
        max: 5, 
    },
    review_text: {
        type: String, 
    },
    created_at: {
        type: Date,
        default: Date.now, 
    },
}, { timestamps: true }); 


const Review = mongoose.model('Review', reviewSchema);

module.exports = Review;
